const Emulators = () => {
  return (
    <div className="p-5 text-text">
      <h2 className="text-xl font-bold mb-4 text-aliceblue">Emulators Settings</h2>
      <p>Configure emulator settings here.</p>
    </div>
  );
};

window.Emulators = Emulators;