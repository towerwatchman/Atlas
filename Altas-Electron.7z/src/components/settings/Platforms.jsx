const Platforms = () => {
  return (
    <div className="p-5 text-text">
      <h2 className="text-xl font-bold mb-4 text-aliceblue">Platforms Settings</h2>
      <p>Configure platform settings here.</p>
    </div>
  );
};

window.Platforms = Platforms;